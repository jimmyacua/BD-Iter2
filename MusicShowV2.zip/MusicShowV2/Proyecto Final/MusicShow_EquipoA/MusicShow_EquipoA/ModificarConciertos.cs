﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;
using MetroFramework;

namespace MusicShow_EquipoA
{
    public partial class ModificarConciertos : MetroForm
    {
        public ModificarConciertos()
        {
            InitializeComponent();
        }

        private void ModificarConciertos_Load(object sender, EventArgs e)
        {

        }
    }
}
