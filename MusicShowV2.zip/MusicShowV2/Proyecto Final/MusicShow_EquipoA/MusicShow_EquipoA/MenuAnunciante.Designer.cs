﻿namespace MusicShow_EquipoA
{
    partial class MenuAnunciante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.ML_Nombre = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.ML_TIPO = new MetroFramework.Controls.MetroLabel();
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            this.metroLink2 = new MetroFramework.Controls.MetroLink();
            this.metroLink3 = new MetroFramework.Controls.MetroLink();
            this.metroLink4 = new MetroFramework.Controls.MetroLink();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.metroLink5 = new MetroFramework.Controls.MetroLink();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 80);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(147, 19);
            this.metroLabel1.TabIndex = 12;
            this.metroLabel1.Text = "Nombre del anunciante";
            // 
            // ML_Nombre
            // 
            this.ML_Nombre.AutoSize = true;
            this.ML_Nombre.Location = new System.Drawing.Point(208, 80);
            this.ML_Nombre.Name = "ML_Nombre";
            this.ML_Nombre.Size = new System.Drawing.Size(80, 19);
            this.ML_Nombre.TabIndex = 13;
            this.ML_Nombre.Text = "MODIFICAR";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(23, 111);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(120, 19);
            this.metroLabel3.TabIndex = 14;
            this.metroLabel3.Text = "Tipo de anunciante";
            // 
            // ML_TIPO
            // 
            this.ML_TIPO.AutoSize = true;
            this.ML_TIPO.Location = new System.Drawing.Point(208, 111);
            this.ML_TIPO.Name = "ML_TIPO";
            this.ML_TIPO.Size = new System.Drawing.Size(80, 19);
            this.ML_TIPO.TabIndex = 15;
            this.ML_TIPO.Text = "MODIFICAR";
            // 
            // metroLink1
            // 
            this.metroLink1.Location = new System.Drawing.Point(127, 40);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(75, 23);
            this.metroLink1.TabIndex = 16;
            this.metroLink1.Text = "Agregar";
            this.metroLink1.UseSelectable = true;
            // 
            // metroLink2
            // 
            this.metroLink2.Location = new System.Drawing.Point(127, 85);
            this.metroLink2.Name = "metroLink2";
            this.metroLink2.Size = new System.Drawing.Size(75, 23);
            this.metroLink2.TabIndex = 17;
            this.metroLink2.Text = "Modificar";
            this.metroLink2.UseSelectable = true;
            // 
            // metroLink3
            // 
            this.metroLink3.Location = new System.Drawing.Point(108, 40);
            this.metroLink3.Name = "metroLink3";
            this.metroLink3.Size = new System.Drawing.Size(75, 23);
            this.metroLink3.TabIndex = 18;
            this.metroLink3.Text = "Agregar";
            this.metroLink3.UseSelectable = true;
            // 
            // metroLink4
            // 
            this.metroLink4.Location = new System.Drawing.Point(82, 85);
            this.metroLink4.Name = "metroLink4";
            this.metroLink4.Size = new System.Drawing.Size(134, 23);
            this.metroLink4.TabIndex = 19;
            this.metroLink4.Text = "Modificar o eliminar";
            this.metroLink4.UseSelectable = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.metroLink1);
            this.groupBox1.Controls.Add(this.metroLink2);
            this.groupBox1.Location = new System.Drawing.Point(38, 181);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(326, 219);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Repertorio";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.metroLink5);
            this.groupBox2.Controls.Add(this.metroLink3);
            this.groupBox2.Controls.Add(this.metroLink4);
            this.groupBox2.Location = new System.Drawing.Point(406, 181);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(288, 219);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Concierto";
            // 
            // metroLink5
            // 
            this.metroLink5.Location = new System.Drawing.Point(82, 124);
            this.metroLink5.Name = "metroLink5";
            this.metroLink5.Size = new System.Drawing.Size(134, 23);
            this.metroLink5.TabIndex = 20;
            this.metroLink5.Text = "Consultar concierto";
            this.metroLink5.UseSelectable = true;
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(594, 41);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 22;
            this.metroButton1.Text = "Cerrar sesión";
            this.metroButton1.UseSelectable = true;
            // 
            // MenuAnunciante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 503);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ML_TIPO);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.ML_Nombre);
            this.Controls.Add(this.metroLabel1);
            this.Name = "MenuAnunciante";
            this.Text = "¿Qué desea hacer?";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel ML_Nombre;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel ML_TIPO;
        private MetroFramework.Controls.MetroLink metroLink1;
        private MetroFramework.Controls.MetroLink metroLink2;
        private MetroFramework.Controls.MetroLink metroLink3;
        private MetroFramework.Controls.MetroLink metroLink4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private MetroFramework.Controls.MetroLink metroLink5;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}